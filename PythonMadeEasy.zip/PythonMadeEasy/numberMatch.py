import random

# welcome players
print("Welcome to the Number Guessing Game: Python Made Easy Edition")
input("<Press enter>")
print()

# ask how many players there will be
numPlayers = input("How many players are there?\nEnter number: ")
while (not numPlayers.isnumeric()):
    numPlayers = input(
        "Input is not a Number. \nHow many players are there?\nEnter number: ")
numPlayers = int(numPlayers)
print()

# ask how many rounds players want to play
playerScore = []
for i in range(numPlayers):
    playerScore.append(0)
numRounds = input("How many rounds would you like to play?\nEnter number: ")
while (not numRounds.isnumeric()):
    numRounds = input(
        "Input is not a Number.\nHow many rounds would you like to play?\nEnter number: ")
numRounds = int(numRounds)
print()

# start the game
turnNum = 0
for i in range(numRounds):
    print("-----------")
    print("| Round " + str(i + 1) + " |")
    print("-----------")
    print()
    answer = random.randint(0, 100)
    answerGuessed = False
    # loop until the number is guessed
    while (not answerGuessed):
        print("Player " + str((turnNum % numPlayers) + 1) + "'s turn")
        playerGuess = input("Guess a number between 0 and 100: ")
        # check for number input
        while (not playerGuess.isnumeric()):
            playerGuess = input(
                "Input is not a Number.\nGuess Number.\nEnter number: ")
        playerGuess = int(playerGuess)
        # check guess with answer and return relation
        if (playerGuess < answer):
            print()
            print("^^^^^^^^^^")
            print("^ Higher ^")
            print("^^^^^^^^^^")
            print()
        elif (playerGuess > answer):
            print()
            print("vvvvvvvvv")
            print("v Lower v")
            print("vvvvvvvvv")
            print()
        else:
            print()
            print("Correct!")
            print()
            playerScore[turnNum %
                        numPlayers] = playerScore[turnNum % numPlayers] + 1
            answerGuessed = True

        turnNum += 1
    # print player scores
    print()
    for j in range(len(playerScore)):
        print("Player " + str(j + 1) + "'s Score: " + str(playerScore[j]))
    print()
