import random

# welcome players
print("Welcome to the Number Guessing Game: Python Made Easy Edition")
input("<Press enter>")
print()

# start the game
isGameOver = False
while not isGameOver:
    answer = random.randint(0, 100)
    isAnswerGuessed = False
    # loop until the number is guessed
    while (not isAnswerGuessed):
        playerGuess = input("Guess a number between 0 and 100: ")
        # check for number input
        while (not playerGuess.isnumeric()):
            playerGuess = input(
                "Input is not a Number.\nGuess Number.\nEnter number: ")
        playerGuess = int(playerGuess)
        # check guess with answer and return relation
        if (playerGuess < answer):
            print()
            print("^^^^^^^^^^")
            print("^ Higher ^")
            print("^^^^^^^^^^")
            print()
        elif (playerGuess > answer):
            print()
            print("vvvvvvvvv")
            print("v Lower v")
            print("vvvvvvvvv")
            print()
        else:
            print()
            print("Correct!")
            print()
            isAnswerGuessed = True

    
    print()
    playAgainInput = input("Game over. Play again? Y or N: ")
    if playAgainInput == "N" or playAgainInput == "n":
        isGameOver = True
    print()
print("Thanks for playing!")
