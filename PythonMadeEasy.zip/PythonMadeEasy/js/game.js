function $(id) {
    return document.getElementById(id);
}

window.onload = function () {
    $("textEditorDiv").focus();
}