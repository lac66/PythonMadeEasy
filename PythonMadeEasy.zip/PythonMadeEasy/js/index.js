function $(id) {
    return document.getElementById(id);
}

window.onload = function () {
    $("htpBtn").focus();
    $("htpBtn").onclick = loadWindow;
    $("consoleBtn").onclick = loadWindow;
    $("variablesBtn").onclick = loadWindow;
    $("operationsBtn").onclick = loadWindow;
    $("cond1Btn").onclick = loadWindow;
    $("cond2Btn").onclick = loadWindow;
    $("gameBtn").onclick = loadWindow;
}

function loadWindow() {
    if (this.id == "htpBtn") {
        window.location.href = "html/howToPlay.html"
    } else if(this.id == "consoleBtn") {
        window.location.href = "html/learningModules/console.html";
    } else if (this.id == "variablesBtn") {
        window.location.href = "html/learningModules/variables.html";
    } else if (this.id == "operationsBtn") {
        window.location.href = "html/learningModules/operations.html";
    } else if (this.id == "cond1Btn") {
        window.location.href = "html/learningModules/conditionals1.html";
    } else if (this.id == "cond2Btn") {
        window.location.href = "html/learningModules/conditionals2.html";
    } else if (this.id == "gameBtn") {
        window.location.href = "html/game.html";
    }
}