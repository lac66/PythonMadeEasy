function getElement(id) {
    return document.getElementById(id);
}

window.onload = function() {
    getElement("consoleBtn").focus();
    getElement("consoleBtn").onclick = loadWindow;
    getElement("variablesBtn").onclick = loadWindow;
    getElement("operationsBtn").onclick = loadWindow;
    getElement("cond1Btn").onclick = loadWindow;
    getElement("cond2Btn").onclick = loadWindow;
}

$(document).ready(function () {
    $("#consoleBtn").mouseover(function() {
        $("#consoleBtn").css('background', '#5b6e5e');
        var url = "../json/console.json";
        var divId = "#console";
        loadContent(url, divId);
    });
    $("#consoleBtn").mouseout(function() {
        $("#consoleBtn").css('background', '#ABCEB0');
        var url = "../json/default.json";
        loadDefaultContent(url);
    });

    $("#variablesBtn").mouseover(function() {
        $("#variablesBtn").css('background', '#5b6e5e');
        var url = "../json/variable.json";
        var divId = "#variables";
        loadContent(url, divId);
    });
    $("#variablesBtn").mouseout(function() {
        $("#variablesBtn").css('background', '#ABCEB0');
        var url = "../json/default.json";
        loadDefaultContent(url);
    });

    $("#operationsBtn").mouseover(function() {
        $("#operationsBtn").css('background', '#5b6e5e');
        var url = "../json/operation.json";
        var divId = "#operations";
        loadContent(url, divId);
    });
    $("#operationsBtn").mouseout(function() {
        $("#operationsBtn").css('background', '#ABCEB0');
        var url = "../json/default.json";
        loadDefaultContent(url);
    });

    $("#cond1Btn").mouseover(function() {
        $("#cond1Btn").css('background', '#5b6e5e');
        var url = "../json/cond1.json";
        var divId = "#cond1";
        loadContent(url, divId);
    });
    $("#cond1Btn").mouseout(function() {
        $("#cond1Btn").css('background', '#ABCEB0');
        var url = "../json/default.json";
        loadDefaultContent(url);
    });

    $("#cond2Btn").mouseover(function() {
        $("#cond2Btn").css('background', '#5b6e5e');
        var url = "../json/cond2.json";
        var divId = "#cond2";
        loadContent(url, divId);
    });
    $("#cond2Btn").mouseout(function() {
        $("#cond2Btn").css('background', '#ABCEB0');
        var url = "../json/default.json";
        loadDefaultContent(url);
    });
});

function loadDefaultContent(url) {
    $.ajax({
        type: "get",
        url: url,
        timeout: 10000,
        error: function(xhr, error) {
            alert("Error: " + xhr.status + " - " + error);
        },
        dataType: "json",
        success: function(data) {
            $("#console").html("");
            $("#variables").html("");
            $("#operations").html("");
            $("#cond1").html("");
            $("#cond2").html("");
            $("#console").append("<h2>" + data.title + "</h2>");
            $("#console").append("<p>" + data.description1 + "</p>");
            $("#console").append("<p>" + data.description2 + "</p>");
            $("#console").append("<p>" + data.description3 + "</p>");

        }
    });
}

function loadContent(url, divId) {
    $.ajax({
        type: "get",
        url: url,
        timeout: 10000,
        error: function(xhr, error) {
            alert("Error: " + xhr.status + " - " + error);
        },
        dataType: "json",
        success: function(data) {
            $("#console").html("");
            $(divId).html("");
            $(divId).append("<h2>" + data.title + "</h2>");
            $(divId).append("<p>" + data.description + "</p>");
        }
    });
}

function loadWindow() {
    if (this.id == "consoleBtn") {
        window.location.href = "learningModules/console.html";
    } else if (this.id == "variablesBtn") {
        window.location.href = "learningModules/variables.html";
    } else if (this.id == "operationsBtn") {
        window.location.href = "learningModules/operations.html";
    } else if (this.id == "cond1Btn") {
        window.location.href = "learningModules/conditionals1.html";
    } else if (this.id == "cond2Btn") {
        window.location.href = "learningModules/conditionals2.html";
    } else {
        loadDefaultContent();
    }
}