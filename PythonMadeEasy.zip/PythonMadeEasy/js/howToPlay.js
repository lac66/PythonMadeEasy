function $(id) {
    return document.getElementById(id);
}

window.onload = function () {
    $("continueBtn").focus();
    $("continueBtn").onclick = loadWindow;
}

function loadWindow() {
    window.open("learningModules/console.html", "_self");
}