function getElement(id) {
    return document.getElementById(id);
}

window.onload = function () {
    getElement("continueBtn").onclick = loadWindow;
}

function loadWindow() {
    if(getElement("title").innerHTML == "Learn: Console") {
        window.open("variables.html", "_self");
    } else if (getElement("title").innerHTML == "Learn: Variables") {
        window.open("operations.html", "_self");
    } else if (getElement("title").innerHTML == "Learn: Operations") {
        window.open("conditionals1.html", "_self");
    } else if (getElement("title").innerHTML == "Learn: Conditionals I") {
        window.open("conditionals2.html", "_self");
    } else if (getElement("title").innerHTML == "Learn: Conditionals II") {
        window.open("../game.html", "_self");
    }
}

$(document).ready(function () {
    $("a[href='#tabs-1']").focus();
    $("#accordion").accordion({
        collapsible: true,
        heightStyle: "content",
    });
    $("#pageContent").tabs();
    $(".draggable").addClass("matchingCards");
    $(".droppable").addClass("matchingCards");

    $("#start").click(function() {
        if ($("input:checked").val() == "hard") {
            $("#drag1 img").hide();
            $("#drag2 img").hide();
            $("#drag3 img").hide();
            $("#drag4 img").hide();
            $("#drag5 img").hide();
            $("#drop1 img").hide();
            $("#drop2 img").hide();
            $("#drop3 img").hide();
            $("#drop4 img").hide();
            $("#drop5 img").hide();
            $("#drag1").mouseover(function() {
                $("#drag1 img").show();
            });
            $("#drag1").mouseout(function() {
                $("#drag1 img").hide();
            });
            $("#drag2").mouseover(function() {
                $("#drag2 img").show();
            });
            $("#drag2").mouseout(function() {
                $("#drag2 img").hide();
            });
            $("#drag3").mouseover(function() {
                $("#drag3 img").show();
            });
            $("#drag3").mouseout(function() {
                $("#drag3 img").hide();
            });
            $("#drag4").mouseover(function() {
                $("#drag4 img").show();
            });
            $("#drag4").mouseout(function() {
                $("#drag4 img").hide();
            });
            $("#drag5").mouseover(function() {
                $("#drag5 img").show();
            });
            $("#drag5").mouseout(function() {
                $("#drag5 img").hide();
            });
            $("#drop1").mouseover(function() {
                $("#drop1 img").show();
            });
            $("#drop1").mouseout(function() {
                $("#drop1 img").hide();
            });
            $("#drop2").mouseover(function() {
                $("#drop2 img").show();
            });
            $("#drop2").mouseout(function() {
                $("#drop2 img").hide();
            });
            $("#drop3").mouseover(function() {
                $("#drop3 img").show();
            });
            $("#drop3").mouseout(function() {
                $("#drop3 img").hide();
            });
            $("#drop4").mouseover(function() {
                $("#drop4 img").show();
            });
            $("#drop4").mouseout(function() {
                $("#drop4 img").hide();
            });
            $("#drop5").mouseover(function() {
                $("#drop5 img").show();
            });
            $("#drop5").mouseout(function() {
                $("#drop5 img").hide();
            });
            
        } else {
            $("#drag1 img").show();
            $("#drag2 img").show();
            $("#drag3 img").show();
            $("#drag4 img").show();
            $("#drag5 img").show();
            $("#drop1 img").show();
            $("#drop2 img").show();
            $("#drop3 img").show();
            $("#drop4 img").show();
            $("#drop5 img").show();
            $("#drag1").mouseout(function() {
                $("#drag1 img").show();
            });
            $("#drag2").mouseout(function() {
                $("#drag2 img").show();
            });
            $("#drag3").mouseout(function() {
                $("#drag3 img").show();
            });
            $("#drag4").mouseout(function() {
                $("#drag4 img").show();
            });
            $("#drag5").mouseout(function() {
                $("#drag5 img").show();
            });
            $("#drop1").mouseout(function() {
                $("#drop1 img").show();
            });
            $("#drop2").mouseout(function() {
                $("#drop2 img").show();
            });
            $("#drop3").mouseout(function() {
                $("#drop3 img").show();
            });
            $("#drop4").mouseout(function() {
                $("#drop4 img").show();
            });
            $("#drop5").mouseout(function() {
                $("#drop5 img").show();
            });
        }
        $("#drag1").draggable({ revert: true});
        $("#drop1").droppable({
            accept: "#drag1",
            drop: function(event, ui) {
                $(this).addClass("correct");
                $("#drag1").addClass("correct");
                $(this).fadeOut();
                $("#drag1").fadeOut();
            }
        });
        $("#drag2").draggable({ revert: true});
        $("#drop2").droppable({
            accept: "#drag2",
            drop: function(event, ui) {
                $(this).addClass("correct");
                $("#drag2").addClass("correct");
                $(this).fadeOut();
                $("#drag2").fadeOut();
            }
        });
        $("#drag3").draggable({ revert: true});
        $("#drop3").droppable({
            accept: "#drag3",
            drop: function(event, ui) {
                $(this).addClass("correct");
                $("#drag3").addClass("correct");
                $(this).fadeOut();
                $("#drag3").fadeOut();
            }
        });
        $("#drag4").draggable({ revert: true});
        $("#drop4").droppable({
            accept: "#drag4",
            drop: function(event, ui) {
                $(this).addClass("correct");
                $("#drag4").addClass("correct");
                $(this).fadeOut();
                $("#drag4").fadeOut();
            }
        });
        $("#drag5").draggable({ revert: true});
        $("#drop5").droppable({
            accept: "#drag5",
            drop: function(event, ui) {
                $(this).addClass("correct");
                $("#drag5").addClass("correct");
                $(this).fadeOut();
                $("#drag5").fadeOut();
            }
        });

        $("#drag1").removeClass("correct");
        $("#drag2").removeClass("correct");
        $("#drag3").removeClass("correct");
        $("#drag4").removeClass("correct");
        $("#drag5").removeClass("correct");
        $("#drop1").removeClass("correct");
        $("#drop2").removeClass("correct");
        $("#drop3").removeClass("correct");
        $("#drop4").removeClass("correct");
        $("#drop5").removeClass("correct");
        $("#drag1").show();
        $("#drag2").show();
        $("#drag3").show();
        $("#drag4").show();
        $("#drag5").show();
        $("#drop1").show();
        $("#drop2").show();
        $("#drop3").show();
        $("#drop4").show();
        $("#drop5").show();
    });
});